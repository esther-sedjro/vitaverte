/* ============ CONFIGURATION UNIQUE : nom, couleur, clés ============ */
window.VV_CONFIG = {
  appName: "VitaVerte",          // nom affiché dans l'app
  accent: "#4CAF50",             // couleur principale (vert)
  accentLight: "#81C784",        // variante claire
  googleClientId: "",            // ID client OAuth Google (voir README)
  facebookAppId: "",             // ID application Facebook (voir README)
  contentUrl: "",                // URL d'un JSON distant de fiches santé (même format que data/health.json)
  syncUrl: ""                    // URL (POST JSON) pour synchroniser l'historique, SI l'utilisateur consent
};
