/* VitaVerte – logique de l'application (JS pur). Tout est commenté en français. */
const C = window.VV_CONFIG, $ = (s, e = document) => e.querySelector(s);
const S = { get: (k, d) => { try { const v = localStorage.getItem('vv:' + k); return v === null ? d : JSON.parse(v); } catch { return d; } }, set: (k, v) => localStorage.setItem('vv:' + k, JSON.stringify(v)) };
const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const today = () => ymd(new Date());
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const ICONS = {
  home: '<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  act: '<path d="M3 17l6-6 4 4 8-9"/><path d="M15 6h6v6"/>',
  health: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
  favs: '<path d="M12 3l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.8 6.1 21l1.2-6.5L2.5 9.9 9.1 9z"/>',
  prof: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  back: '<path d="M15 6l-6 6 6 6"/>', drop: '<path d="M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11z"/>'
};
const I = (n, s = 22) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>`;
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('on'), 2600); }

/* ---------- État persistant (localStorage, fonctionne hors ligne) ---------- */
let set = S.get('set', { dark: false, units: 'km', notif: true, consent: false });
let prof = S.get('prof', { weight: 70, height: 170 });
let goals = S.get('goals', { dist: 5, steps: 8000 });
let hist = S.get('hist', []), water = S.get('water', {}), weights = S.get('weights', []), favs = S.get('favs', []), rem = S.get('rem', []);
let content = S.get('content', null), session = S.get('session', null);
const dist = km => set.units === 'mi' ? (km * 0.621371).toFixed(2) + ' mi' : km.toFixed(2) + ' km';
const hms = s => [s / 3600 | 0, (s % 3600) / 60 | 0, s % 60 | 0].map(x => String(x).padStart(2, '0')).join(':');
function theme() {
  document.documentElement.dataset.theme = set.dark ? 'dark' : '';
  const r = document.documentElement.style; r.setProperty('--g', C.accent); r.setProperty('--gl', C.accentLight); document.title = C.appName;
}

/* ---------- Authentification locale + OAuth Google/Facebook ---------- */
const sha = async s => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)))].map(b => b.toString(16).padStart(2, '0')).join('');
const users = () => S.get('users', {});
const okPw = p => p.length >= 8 && /\d/.test(p);
function login(u) { session = u; S.set('session', u); boot(); }
function loadScript(src) { return new Promise((ok, ko) => { const s = document.createElement('script'); s.src = src; s.onload = ok; s.onerror = () => ko(); document.head.appendChild(s); }); }
let authMode = 'in';
function authView() {
  $('#app').innerHTML = `<div class="full-screen"><h1 style="color:var(--g);margin:0">${esc(C.appName)}</h1><p class="mut">Votre bien-être, simplement.</p>
  <div class="seg"><button data-a="am" data-v="in" class="${authMode === 'in' ? 'on' : ''}">Connexion</button><button data-a="am" data-v="up" class="${authMode === 'up' ? 'on' : ''}">Inscription</button></div>
  ${authMode === 'up' ? '<input id="nm" placeholder="Prénom" autocomplete="name">' : ''}
  <input id="em" type="email" placeholder="Email" autocomplete="email">
  <div class="pw"><input id="pw" type="password" placeholder="Mot de passe (8 caractères, 1 chiffre)"><button data-a="eye">${I('eye')}</button></div>
  <button class="btn full" data-a="auth">${authMode === 'in' ? 'Se connecter' : 'Créer mon compte'}</button>
  ${authMode === 'in' ? '<p style="text-align:right"><a href="#" data-a="forgot" class="mut">Mot de passe oublié ?</a></p>' : ''}
  <button class="btn alt full" data-a="google" style="margin-top:8px">Continuer avec Google</button>
  <button class="btn alt full" data-a="fb" style="margin-top:8px">Continuer avec Facebook</button>
  <button class="btn red full" data-a="guest" style="margin-top:8px;border-color:transparent;color:var(--mut)">Continuer sans compte</button></div>`;
}
function onboard(i = 0) {
  const P = [['Bougez à votre rythme', 'Marche, course, vélo : distance, pas et calories, sans capteur médical.'], ['Des conseils fiables', 'Fiches santé sourcées (OMS…), lisibles même sans connexion.'], ['Vos données restent chez vous', 'Rien n\'est envoyé sans votre accord.']];
  $('#app').innerHTML = `<div class="full-screen" style="text-align:center"><div style="font-size:64px;color:var(--g)">${I(['act', 'health', 'prof'][i], 72)}</div><h2>${P[i][0]}</h2><p class="mut">${P[i][1]}</p>
  <div class="dots">${P.map((_, k) => `<i class="${k === i ? 'on' : ''}"></i>`).join('')}</div>
  <button class="btn full" data-a="onb" data-v="${i + 1}">${i < 2 ? 'Suivant' : 'Commencer'}</button><button class="btn alt full" style="margin-top:8px" data-a="onb" data-v="3">Passer</button></div>`;
}

/* ---------- Contenu santé (JSON local, mis à jour en ligne si contentUrl) ---------- */
async function loadContent() {
  if (!content) { try { content = await (await fetch('data/health.json')).json(); } catch { content = { categories: {}, fiches: [], avertissement: '' }; } }
  if (C.contentUrl && navigator.onLine) { try { content = await (await fetch(C.contentUrl)).json(); S.set('content', content); } catch { } }
}

/* ---------- Statistiques ---------- */
const dayTot = d => hist.filter(h => h.date === d).reduce((a, h) => ({ dist: a.dist + h.dist, steps: a.steps + h.steps, kcal: a.kcal + h.kcal, sec: a.sec + h.sec }), { dist: 0, steps: 0, kcal: 0, sec: 0 });
const lastDays = n => [...Array(n)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (n - 1 - i)); return ymd(d); });
const bmi = () => prof.weight / Math.pow(prof.height / 100, 2);
const bmiLabel = b => b < 18.5 ? 'insuffisance pondérale' : b < 25 ? 'poids normal' : b < 30 ? 'surpoids' : 'obésité';
function ring(p, big, sub) {
  const c = 2 * Math.PI * 52;
  return `<svg viewBox="0 0 130 130" width="150" height="150"><circle cx="65" cy="65" r="52" fill="none" stroke="var(--tint)" stroke-width="12"/><circle cx="65" cy="65" r="52" fill="none" stroke="var(--g)" stroke-width="12" stroke-linecap="round" stroke-dasharray="${c * Math.min(1, p)} ${c}" transform="rotate(-90 65 65)"/><text x="65" y="64" text-anchor="middle" font-size="20" font-weight="600" fill="var(--g)">${big}</text><text x="65" y="84" text-anchor="middle" font-size="10" fill="var(--mut)">${sub}</text></svg>`;
}
function bars(vals, labels) {
  const m = Math.max(...vals, .01), w = 300 / vals.length;
  return `<svg viewBox="0 0 300 120" width="100%">${vals.map((v, i) => `<rect x="${i * w + 2}" y="${100 - v / m * 90}" width="${w - 4}" height="${v / m * 90}" rx="4" fill="${v ? 'var(--g)' : 'var(--tint)'}"/>${labels[i] ? `<text x="${i * w + w / 2}" y="114" text-anchor="middle" font-size="8" fill="var(--mut)">${labels[i]}</text>` : ''}`).join('')}</svg>`;
}
function trace(pts) {
  if (!pts || pts.length < 2) return '<div class="empty">Pas de tracé GPS</div>';
  const xs = pts.map(p => p[1]), ys = pts.map(p => p[0]), x0 = Math.min(...xs), y0 = Math.min(...ys), sx = Math.max(...xs) - x0 || 1e-5, sy = Math.max(...ys) - y0 || 1e-5, k = Math.min(280 / sx, 140 / sy);
  const d = pts.map(p => `${10 + (p[1] - x0) * k},${150 - (p[0] - y0) * k}`).join(' ');
  return `<svg viewBox="0 0 300 160" width="100%"><polyline points="${d}" fill="none" stroke="var(--g)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}

/* ---------- Suivi GPS ---------- */
const MET = { walk: 3.5, run: 8.5, bike: 6.8 }, NAMES = { walk: 'Marche', run: 'Course', bike: 'Vélo' };
let T = null, watchId = null, mode = 'walk', period = 7;
const elapsed = () => T ? T.acc + (T.paused ? 0 : (Date.now() - T.last) / 1000) : 0;
const liveVals = () => { const s = elapsed(), stride = prof.height * 0.415 / 100 * (mode === 'run' ? 1.25 : 1); return { s, steps: mode === 'bike' ? 0 : Math.round(T.dist * 1000 / stride), kcal: MET[mode] * prof.weight * s / 3600 }; };
const hav = (a, b) => { const r = x => x * Math.PI / 180, R = 6371, dl = r(b[0] - a[0]), dn = r(b[1] - a[1]); const h = Math.sin(dl / 2) ** 2 + Math.cos(r(a[0])) * Math.cos(r(b[0])) * Math.sin(dn / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
async function askGeo() { const g = window.Capacitor?.Plugins?.Geolocation; if (g) { try { const p = await g.requestPermissions(); return p.location !== 'denied'; } catch { } } return !!navigator.geolocation; }
function onPos(p) {
  if (!T || T.paused || p.coords.accuracy > 30) return;
  const pt = [p.coords.latitude, p.coords.longitude], l = T.pts[T.pts.length - 1];
  if (l) { const d = hav(l, pt); if (d < 0.002 || d > 0.2) return; T.dist += d; }
  T.pts.push(pt);
}
function refreshLive() { if (tab !== 'act' || !T) return; const v = liveVals(); $('#lt') && ($('#lt').textContent = hms(v.s), $('#ld').textContent = dist(T.dist), $('#ls').textContent = v.steps, $('#lk').textContent = Math.round(v.kcal)); }
setInterval(refreshLive, 1000);

/* ---------- Rappels (notifications locales Capacitor) ---------- */
async function schedule() {
  const L = window.Capacitor?.Plugins?.LocalNotifications; if (!L || !set.notif) return;
  try {
    await L.requestPermissions(); const p = await L.getPending(); if (p.notifications.length) await L.cancel(p);
    if (rem.length) await L.schedule({ notifications: rem.map((r, i) => { const [h, m] = r.time.split(':').map(Number); return { id: i + 1, title: C.appName, body: r.label, schedule: { on: { hour: h, minute: m }, allowWhileIdle: true } }; }) });
  } catch (e) { console.warn(e); }
}
/* Synchronisation à la reconnexion : uniquement si consentement + syncUrl renseignée */
async function sync() { if (!set.consent || !C.syncUrl || !navigator.onLine) return; try { await fetch(C.syncUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ hist, weights }) }); } catch { } }

/* ---------- Pages ---------- */
const TABS = [['home', 'Accueil'], ['act', 'Activité'], ['health', 'Santé'], ['favs', 'Favoris'], ['prof', 'Profil']];
let tab = 'home', cat = 'all';
const PAGES = {
  home() {
    const t = dayTot(today()), w = water[today()] || 0, b = bmi(), f = content.fiches.length ? content.fiches[Math.floor(Date.now() / 864e5) % content.fiches.length] : null;
    return `<h2>Bonjour${session?.name ? ' ' + esc(session.name) : ''} 👋</h2>
    <div class="card row sp">${ring(t.steps / goals.steps, t.steps, 'pas / ' + goals.steps)}<div><div class="mut">Distance</div><div class="big">${dist(t.dist)}</div><div class="mut">Objectif ${dist(goals.dist)}</div><div class="mut" style="margin-top:8px">${Math.round(t.kcal)} kcal · ${hms(t.sec)}</div></div></div>
    <div class="card"><div class="row sp"><h3>${I('drop', 18)} Eau</h3><span class="big">${w} ml</span></div><div class="row"><button class="btn alt" data-a="water" data-v="-250">−250</button><button class="btn" data-a="water" data-v="250" style="flex:1">+ un verre (250 ml)</button></div><div class="mut" style="margin-top:6px">Objectif : 2000 ml</div></div>
    <div class="card"><h3>Poids & IMC</h3><div class="row sp"><span class="big">${prof.weight} kg</span><span class="mut">IMC ${b.toFixed(1)} · ${bmiLabel(b)}</span></div></div>
    ${f ? `<div class="card" data-a="fiche" data-v="${f.id}" style="cursor:pointer"><div class="mut">Conseil du jour</div><h3>${esc(f.titre)}</h3><div>${esc(f.prevention?.[0] || f.definition)}</div></div>` : ''}`;
  },
  act() {
    const live = T ? liveVals() : null, days = lastDays(period), v = days.map(d => dayTot(d).dist);
    return `<h2>Activité</h2><div class="card">
    <div class="seg">${Object.keys(NAMES).map(k => `<button data-a="mode" data-v="${k}" class="${mode === k ? 'on' : ''}">${NAMES[k]}</button>`).join('')}</div>
    <div class="grid" style="text-align:center"><div><div class="mut">Durée</div><div class="big" id="lt">${hms(live ? live.s : 0)}</div></div><div><div class="mut">Distance</div><div class="big" id="ld">${dist(T ? T.dist : 0)}</div></div><div><div class="mut">Pas</div><div class="big" id="ls">${live ? live.steps : 0}</div></div><div><div class="mut">Calories</div><div class="big" id="lk">${live ? Math.round(live.kcal) : 0}</div></div></div>
    <div class="row" style="margin-top:12px">${!T ? '<button class="btn full" data-a="start">Démarrer</button>' : `<button class="btn alt" style="flex:1" data-a="pause">${T.paused ? 'Reprendre' : 'Pause'}</button><button class="btn" style="flex:1" data-a="stop">Terminer</button>`}</div>
    ${T ? trace(T.pts) : ''}</div>
    <div class="card"><div class="seg"><button data-a="per" data-v="7" class="${period === 7 ? 'on' : ''}">Semaine</button><button data-a="per" data-v="30" class="${period === 30 ? 'on' : ''}">Mois</button></div>${bars(v, days.map((d, i) => period === 7 ? 'LMMJVSD'[(new Date(d + 'T12:00').getDay() + 6) % 7] : i % 5 === 0 ? d.slice(8) : ''))}<div class="mut">Total : ${dist(v.reduce((a, b) => a + b, 0))}</div></div>
    <div class="card"><h3>Objectifs quotidiens</h3><div class="grid"><div><span class="mut">Distance (km)</span><input id="gd" type="number" min="0.5" step="0.5" value="${goals.dist}"></div><div><span class="mut">Pas</span><input id="gs" type="number" min="500" step="500" value="${goals.steps}"></div></div><button class="btn alt full" data-a="goals">Enregistrer</button></div>
    <div class="card"><h3>Historique</h3>${hist.length ? hist.slice().reverse().slice(0, 30).map(h => `<div class="item" data-a="sortie" data-v="${h.id}"><div><b>${NAMES[h.mode]}</b> <span class="mut">${h.date}</span></div><span>${dist(h.dist)} · ${hms(h.sec)}</span></div>`).join('') : '<div class="empty">Aucune sortie pour le moment. Appuyez sur Démarrer.</div>'}</div>`;
  },
  health() {
    return `<h2>Conseils santé</h2><div class="warn">⚠️ ${esc(content.avertissement || 'Information uniquement : ne remplace jamais un médecin, aucun diagnostic.')}</div>
    <input id="q" type="search" placeholder="Rechercher (paludisme, sommeil…)"><div class="chips"><button class="chip ${cat === 'all' ? 'on' : ''}" data-a="cat" data-v="all">Tout</button>${Object.entries(content.categories).map(([k, l]) => `<button class="chip ${cat === k ? 'on' : ''}" data-a="cat" data-v="${k}">${esc(l)}</button>`).join('')}</div><div class="card" id="list"></div>`;
  },
  healthInit() { fillList(); $('#q').oninput = fillList; },
  favs() { const l = content.fiches.filter(f => favs.includes(f.id)); return `<h2>Favoris</h2><div class="card">${l.length ? l.map(ficheRow).join('') : '<div class="empty">Aucun favori. Touchez l\'étoile d\'une fiche pour la garder ici.</div>'}</div>`; },
  prof() {
    const b = bmi(), sw = (k, l, on) => `<div class="tog"><span>${l}</span><button class="sw ${on ? 'on' : ''}" data-a="tog" data-v="${k}"></button></div>`;
    return `<h2>Profil</h2><div class="card"><h3>${esc(session?.name || 'Invité')}</h3><div class="mut">${esc(session?.email || 'Mode sans compte')}</div></div>
    <div class="card"><h3>Poids, taille & IMC</h3><div class="grid"><div><span class="mut">Poids (kg)</span><input id="pw8" type="number" step="0.1" value="${prof.weight}"></div><div><span class="mut">Taille (cm)</span><input id="ht" type="number" value="${prof.height}"></div></div><button class="btn alt full" data-a="body">Enregistrer</button><p>IMC <b>${b.toFixed(1)}</b> · ${bmiLabel(b)}</p>${weights.slice(-4).map(x => `<div class="mut">${x.date} : ${x.kg} kg</div>`).join('')}</div>
    <div class="card"><h3>Rappels</h3>${rem.map((r, i) => `<div class="item"><span>${esc(r.label)} <span class="mut">${r.time}</span></span><button class="star" data-a="rdel" data-v="${i}">✕</button></div>`).join('') || '<div class="mut">Aucun rappel.</div>'}
    <select id="rt"><option value="Boire un verre d'eau">Eau</option><option value="C'est l'heure de marcher">Marche</option><option value="Prendre mon médicament">Médicament</option></select><input id="rh" type="time" value="08:00"><button class="btn alt full" data-a="radd">Ajouter</button></div>
    <div class="card"><h3>Paramètres</h3>${sw('dark', 'Mode sombre', set.dark)}${sw('units', 'Unités en miles', set.units === 'mi')}${sw('notif', 'Notifications', set.notif)}${sw('consent', 'Autoriser la synchronisation de mes données', set.consent)}<div class="mut">Langue : Français · Aucune donnée n'est envoyée sans votre accord.</div></div>
    <button class="btn alt full" data-a="logout">Se déconnecter</button><button class="btn red full" style="margin-top:10px" data-a="del">Supprimer mon compte et mes données</button>`;
  }
};
const ficheRow = f => `<div class="item" data-a="fiche" data-v="${f.id}"><div><b>${esc(f.titre)}</b><div class="mut">${esc(content.categories[f.cat] || '')}</div></div><button class="star ${favs.includes(f.id) ? 'on' : ''}" data-a="fav" data-v="${f.id}">${I('favs', 20)}</button></div>`;
function fillList() {
  const q = norm($('#q')?.value || ''), l = content.fiches.filter(f => (cat === 'all' || f.cat === cat) && norm(f.titre + ' ' + f.definition + ' ' + (f.symptomes || []).join(' ')).includes(q));
  $('#list').innerHTML = l.length ? l.map(ficheRow).join('') : '<div class="empty">Aucun résultat. Essayez un autre mot ou une autre catégorie.</div>';
}
function sheet(html) { const d = document.createElement('div'); d.className = 'sheet'; d.innerHTML = `<button class="btn alt" data-a="close">${I('back', 18)} Retour</button>${html}`; document.body.appendChild(d); }
function ficheView(f) {
  const L = (t, a) => a?.length ? `<h3>${t}</h3><ul>${a.map(x => `<li>${esc(x)}</li>`).join('')}</ul>` : '';
  sheet(`<h2>${esc(f.titre)}</h2><div class="warn">${esc(content.avertissement || '')}</div><p>${esc(f.definition)}</p>${L('Causes', f.causes)}${L('Symptômes', f.symptomes)}${L('Prévention', f.prevention)}${L('Bonnes habitudes', f.habitudes)}${L('Quand consulter', f.consulter)}<p class="mut">Source : ${esc(f.source)}</p><button class="btn full" data-a="fav" data-v="${f.id}">${favs.includes(f.id) ? 'Retirer des favoris' : 'Ajouter aux favoris'}</button>`);
}

/* ---------- Actions (délégation de clics) ---------- */
const A = {
  tab: v => { tab = v; show(); },
  close: () => document.querySelector('.sheet')?.remove(),
  am: v => { authMode = v; authView(); },
  eye: () => { const p = $('#pw'); p.type = p.type === 'password' ? 'text' : 'password'; },
  onb: v => { v = +v; if (v >= 3) { S.set('onb', 1); boot(); } else onboard(v); },
  guest: () => login({ guest: true, name: '' }),
  async auth() {
    const em = $('#em').value.trim().toLowerCase(), pw = $('#pw').value, nm = $('#nm')?.value.trim(), U = users();
    if (!/^\S+@\S+\.\S+$/.test(em)) return toast('Email invalide.');
    if (authMode === 'up') {
      if (!nm) return toast('Indiquez votre prénom.'); if (!okPw(pw)) return toast('Mot de passe : 8 caractères minimum dont 1 chiffre.'); if (U[em]) return toast('Un compte existe déjà avec cet email.');
      U[em] = { name: nm, hash: await sha(pw) }; S.set('users', U); login({ email: em, name: nm });
    } else {
      if (!U[em] || U[em].hash !== await sha(pw)) return toast('Email ou mot de passe incorrect.'); login({ email: em, name: U[em].name });
    }
  },
  async forgot() {
    const em = (prompt('Votre email :') || '').trim().toLowerCase(), U = users(); if (!U[em]) return toast('Aucun compte local avec cet email.');
    const p = prompt('Nouveau mot de passe (8 caractères min., 1 chiffre) :') || ''; if (!okPw(p)) return toast('Mot de passe trop faible.');
    U[em].hash = await sha(p); S.set('users', U); toast('Mot de passe modifié.');
  },
  async google() {
    if (!C.googleClientId) return toast('Renseignez googleClientId dans www/config.js (voir README).'); if (!navigator.onLine) return toast('Connexion Internet requise.');
    try { await loadScript('https://accounts.google.com/gsi/client'); google.accounts.oauth2.initTokenClient({ client_id: C.googleClientId, scope: 'openid email profile', callback: async r => { const u = await (await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: 'Bearer ' + r.access_token } })).json(); login({ email: u.email, name: u.given_name || u.name, provider: 'google' }); } }).requestAccessToken(); } catch { toast('Connexion Google impossible.'); }
  },
  async fb() {
    if (!C.facebookAppId) return toast('Renseignez facebookAppId dans www/config.js (voir README).'); if (!navigator.onLine) return toast('Connexion Internet requise.');
    try { await loadScript('https://connect.facebook.net/fr_FR/sdk.js'); FB.init({ appId: C.facebookAppId, version: 'v19.0' }); FB.login(r => { if (r.authResponse) FB.api('/me', { fields: 'name,email' }, u => login({ email: u.email || '', name: (u.name || '').split(' ')[0], provider: 'facebook' })); }, { scope: 'public_profile,email' }); } catch { toast('Connexion Facebook impossible.'); }
  },
  logout: () => { S.set('session', null); session = null; boot(); },
  del() { if (!confirm('Supprimer le compte et TOUTES les données de cet appareil ?')) return; Object.keys(localStorage).filter(k => k.startsWith('vv:')).forEach(k => localStorage.removeItem(k)); location.reload(); },
  water(v) { water[today()] = Math.max(0, (water[today()] || 0) + +v); S.set('water', water); show(); },
  mode: v => { if (!T) { mode = v; show(); } },
  per: v => { period = +v; show(); },
  goals() { goals = { dist: +$('#gd').value || 5, steps: +$('#gs').value || 8000 }; S.set('goals', goals); toast('Objectifs enregistrés.'); },
  async start() {
    if (!await askGeo()) return toast('Localisation refusée : activez-la dans les réglages du téléphone.');
    T = { mode, acc: 0, last: Date.now(), paused: false, pts: [], dist: 0 };
    watchId = navigator.geolocation.watchPosition(onPos, () => toast('Signal GPS indisponible.'), { enableHighAccuracy: true, maximumAge: 0, timeout: 20000 }); show();
  },
  pause() { if (T.paused) { T.last = Date.now(); T.paused = false; } else { T.acc += (Date.now() - T.last) / 1000; T.paused = true; } show(); },
  stop() {
    const v = liveVals(); navigator.geolocation.clearWatch(watchId);
    if (T.dist < 0.01) { toast('Sortie trop courte : non enregistrée.'); } else {
      const k = Math.ceil(T.pts.length / 200); hist.push({ id: Date.now() + '', date: today(), mode, dist: T.dist, sec: Math.round(v.s), steps: v.steps, kcal: v.kcal, pts: T.pts.filter((_, i) => i % k === 0) }); S.set('hist', hist); toast('Sortie enregistrée.'); sync();
    }
    T = null; show();
  },
  sortie(v) { const h = hist.find(x => x.id === v); sheet(`<h2>${NAMES[h.mode]} · ${h.date}</h2>${trace(h.pts)}<div class="grid"><div class="card"><div class="mut">Distance</div><div class="big">${dist(h.dist)}</div></div><div class="card"><div class="mut">Durée</div><div class="big">${hms(h.sec)}</div></div><div class="card"><div class="mut">Pas</div><div class="big">${h.steps}</div></div><div class="card"><div class="mut">Calories</div><div class="big">${Math.round(h.kcal)}</div></div></div>`); },
  cat: v => { cat = v; show(); },
  fiche: v => ficheView(content.fiches.find(f => f.id === v)),
  fav(v, el) { favs = favs.includes(v) ? favs.filter(x => x !== v) : [...favs, v]; S.set('favs', favs); if (el.classList.contains('btn')) { A.close(); } if (tab === 'favs') show(); else if (tab === 'health') fillList(); else el.classList.toggle('on'); },
  body() { const w = +$('#pw8').value, h = +$('#ht').value; if (!(w > 20 && w < 300 && h > 100 && h < 250)) return toast('Valeurs de poids ou de taille invalides.'); prof = { weight: w, height: h }; S.set('prof', prof); weights.push({ date: today(), kg: w }); S.set('weights', weights); show(); },
  radd() { rem.push({ label: $('#rt').value, time: $('#rh').value || '08:00' }); S.set('rem', rem); schedule(); if (!window.Capacitor) toast('Les notifications fonctionnent dans l\'application Android.'); show(); },
  rdel(v) { rem.splice(+v, 1); S.set('rem', rem); schedule(); show(); },
  tog(v) { if (v === 'units') set.units = set.units === 'mi' ? 'km' : 'mi'; else set[v] = !set[v]; S.set('set', set); theme(); if (v === 'notif') schedule(); show(); }
};
document.addEventListener('click', e => { const t = e.target.closest('[data-a]'); if (!t) return; if (t.tagName === 'A') e.preventDefault(); e.stopPropagation(); A[t.dataset.a]?.(t.dataset.v, t); });

/* ---------- Démarrage ---------- */
function shell() {
  $('#app').innerHTML = `<header class="top"><b>${esc(C.appName)}</b><span class="net"><i></i><u class="on" style="text-decoration:none">En ligne</u><u class="off" style="text-decoration:none">Hors ligne</u></span></header><main id="view"></main><nav class="bar">${TABS.map(([k, l]) => `<button data-a="tab" data-v="${k}">${I(k)}<span>${l}</span></button>`).join('')}</nav>`; show();
}
function show() {
  const v = $('#view'); v.className = ''; void v.offsetWidth; v.className = 'enter'; v.innerHTML = PAGES[tab](); PAGES[tab + 'Init']?.();
  document.querySelectorAll('.bar button').forEach(b => b.classList.toggle('on', b.dataset.v === tab));
}
function net() { document.body.classList.toggle('offline', !navigator.onLine); }
addEventListener('online', () => { net(); sync(); loadContent(); }); addEventListener('offline', net);
async function boot() {
  theme(); net(); await loadContent();
  if (!S.get('onb', 0)) return onboard(0);
  if (!session) return authView();
  shell(); schedule();
}
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => { });
boot();
