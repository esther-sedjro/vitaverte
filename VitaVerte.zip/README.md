# VitaVerte – application santé & bien-être (Capacitor / Android)

HTML + CSS + JS pur, empaqueté avec Capacitor. Fonctionne aussi comme PWA (`www/sw.js` + `manifest.webmanifest`).

## Structure
- `www/config.js` : **fichier unique** (nom, couleur, clés Google/Facebook, URL de contenu/synchro)
- `www/js/app.js` : logique (auth, GPS, pages) · `www/css/app.css` : styles
- `www/data/health.json` : fiches santé · `www/assets/` : icône
- `capacitor.config.json` : `appId` / `appName` Android

## Obtenir l'APK
**Option A – GitHub (aucune installation)** : créez un dépôt, poussez ce dossier sur `main`. L'onglet *Actions* → « Build APK » produit l'artefact `VitaVerte-debug-apk` (`app-debug.apk`).

**Option B – en local** (Node 18+, JDK 17, Android Studio) :
```
npm install
npx cap add android        # une seule fois
npx cap sync android
npx cap open android       # puis Build > Build APK(s)   (ou :)
cd android && ./gradlew assembleDebug    # APK : android/app/build/outputs/apk/debug/
```
Ajoutez dans `android/app/src/main/AndroidManifest.xml` (avant `</manifest>`) si absents :
`ACCESS_FINE_LOCATION`, `ACCESS_COARSE_LOCATION`, `POST_NOTIFICATIONS`.

**APK release signé** : `keytool -genkey -v -keystore vv.jks -alias vv -keyalg RSA -keysize 2048 -validity 10000`, puis Android Studio > Build > Generate Signed Bundle / APK.

## Tester dans le navigateur
`npm run serve` (ouvre `www/`). Le GPS et le service worker demandent HTTPS ou localhost.

## Personnaliser
- **Nom** : `appName` dans `www/config.js` ET dans `capacitor.config.json` (puis `npx cap sync`).
- **Couleurs** : `accent` / `accentLight` dans `www/config.js`.
- **Contenu santé** : éditez `www/data/health.json` (champs : `id`, `cat`, `titre`, `definition`, `causes`, `symptomes`, `prevention`, `habitudes`, `consulter`, `source`). Mise à jour distante : hébergez un JSON de même format et renseignez `contentUrl`.
  Les fiches fournies sont un point de départ : faites-les relire par un professionnel de santé avant publication, et ajoutez-en d'autres.

## Google / Facebook
- **Google** : console.cloud.google.com → Identifiants → ID client OAuth (type Web), origine autorisée `https://localhost` → collez-le dans `googleClientId`.
- **Facebook** : developers.facebook.com → créez une app « Connexion Facebook » → collez l'App ID dans `facebookAppId`.
- ⚠️ Google et Facebook limitent OAuth dans les WebView. Pour une publication Play Store, utilisez un plugin natif (ex. `@capacitor-firebase/authentication`) et adaptez `A.google` / `A.fb` dans `app.js`.

## Limites connues
- Comptes e-mail stockés **localement** (mot de passe haché SHA-256) ; « mot de passe oublié » réinitialise localement. Pour un vrai envoi d'e-mail, branchez un backend (Firebase Auth, Supabase…).
- Rappels : notifications locales Capacitor (dans l'APK uniquement).
- Les estimations de pas/calories sont indicatives (longueur de pas selon la taille, valeurs MET).
